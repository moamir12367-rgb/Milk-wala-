package com.milkman.pro;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.ActivityNotFoundException;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.telephony.SmsManager;
import android.text.InputType;
import android.webkit.DownloadListener;
import android.webkit.JsPromptResult;
import android.webkit.JsResult;
import android.webkit.URLUtil;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends AppCompatActivity {

    private static final String HOST = "appassets.androidplatform.net";
    private static final String HOME = "https://" + HOST + "/assets/index.html";

    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private ActivityResultLauncher<Intent> chooserLauncher;
    private ActivityResultLauncher<String> notifPermLauncher;
    private ActivityResultLauncher<String> smsPermLauncher;
    static final String SMS_SENT = "com.milkman.pro.SMS_SENT";

    private final BroadcastReceiver smsSentReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String req = safe(intent.getStringExtra("req"));
            int code = getResultCode();
            jsCall("window.onSmsSent&&window.onSmsSent('" + req + "'," + (code == Activity.RESULT_OK) + "," + code + ")");
        }
    };

    private static String safe(String s) {
        return s == null ? "" : s.replaceAll("[^A-Za-z0-9_]", "");
    }

    void jsCall(final String js) {
        if (web != null) web.post(() -> web.evaluateJavascript(js, null));
    }

    boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    void requestSmsPermission() {
        if (hasSmsPermission()) jsCall("window.onSmsPermission&&window.onSmsPermission(true)");
        else smsPermLauncher.launch(Manifest.permission.SEND_SMS);
    }

    /** Phone ki SIM se SMS bhejta hai. Result JS ko window.onSmsSent(reqId, ok, code) se milta hai. */
    void sendSmsNow(String number, String text, String reqId) {
        final String req = safe(reqId);
        if (!hasSmsPermission()) {
            jsCall("window.onSmsSent&&window.onSmsSent('" + req + "',false,-1)");
            return;
        }
        try {
            String n = number == null ? "" : number.replaceAll("[^0-9+]", "");
            if (n.length() < 8) throw new IllegalArgumentException("number");
            SmsManager sm = Build.VERSION.SDK_INT >= 31 ? getSystemService(SmsManager.class) : SmsManager.getDefault();
            Intent in = new Intent(SMS_SENT).setPackage(getPackageName()).putExtra("req", req);
            PendingIntent pi = PendingIntent.getBroadcast(this, Math.abs(req.hashCode()), in,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            sm.sendTextMessage(n, null, text, pi, null);
        } catch (Exception e) {
            jsCall("window.onSmsSent&&window.onSmsSent('" + req + "',false,-2)");
        }
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ReminderScheduler.createChannel(this);

        chooserLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
            Uri[] uris = null;
            if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                uris = WebChromeClient.FileChooserParams.parseResult(result.getResultCode(), result.getData());
            }
            if (filePathCallback != null) {
                filePathCallback.onReceiveValue(uris);
                filePathCallback = null;
            }
        });
        notifPermLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                granted -> maybeAskBattery());
        smsPermLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                granted -> jsCall("window.onSmsPermission&&window.onSmsPermission(" + granted + ")"));
        ContextCompat.registerReceiver(this, smsSentReceiver, new IntentFilter(SMS_SENT),
                ContextCompat.RECEIVER_NOT_EXPORTED);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setSupportMultipleWindows(false);
        s.setTextZoom(100);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if (HOST.equals(u.getHost())) return false;
                openExternal(u);   // WhatsApp, browser, tel: etc.
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    chooserLauncher.launch(params.createIntent());
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }

            @Override
            public boolean onJsAlert(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsConfirm(WebView view, String url, String message, final JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setPositiveButton("OK", (d, w) -> result.confirm())
                        .setNegativeButton("Cancel", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }

            @Override
            public boolean onJsPrompt(WebView view, String url, String message, String defaultValue,
                                      final JsPromptResult result) {
                final EditText input = new EditText(MainActivity.this);
                input.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                input.setText(defaultValue == null ? "" : defaultValue);
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage(message)
                        .setView(input)
                        .setPositiveButton("OK", (d, w) -> result.confirm(input.getText().toString()))
                        .setNegativeButton("Cancel", (d, w) -> result.cancel())
                        .setOnCancelListener(d -> result.cancel())
                        .show();
                return true;
            }
        });

        // PDF / file download (jsPDF blob: link) ko Downloads folder mein save karna
        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String url, String userAgent, String contentDisposition,
                                        String mimetype, long contentLength) {
                if (url.startsWith("blob:")) {
                    String mime = (mimetype == null || mimetype.isEmpty()) ? "application/octet-stream" : mimetype;
                    String name = URLUtil.guessFileName(url, contentDisposition, mime);
                    if (mime.contains("pdf")) name = "MilkBill.pdf";
                    name = name.replaceAll("[^A-Za-z0-9._-]", "_");
                    mime = mime.replaceAll("[^A-Za-z0-9./+-]", "");
                    String js = "(function(){var x=new XMLHttpRequest();x.open('GET','" + url + "',true);"
                            + "x.responseType='blob';x.onload=function(){var r=new FileReader();"
                            + "r.onloadend=function(){try{Android.saveFile(String(r.result).split(',')[1],'"
                            + name + "','" + mime + "');}catch(e){}};r.readAsDataURL(x.response);};x.send();})();";
                    web.evaluateJavascript(js, null);
                } else {
                    openExternal(Uri.parse(url));
                }
            }
        });

        web.addJavascriptInterface(new AndroidBridge(this), "Android");

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (web.canGoBack()) {
                    web.goBack();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });

        if (savedInstanceState == null) {
            web.loadUrl(HOME);
        } else {
            web.restoreState(savedInstanceState);
        }

        askNotificationPermission();
    }

    private void openExternal(Uri u) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, u));
        } catch (ActivityNotFoundException ignored) {
        }
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            notifPermLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
        } else {
            maybeAskBattery();
        }
    }

    /** Oppo/ColorOS par app band hone par bhi alarm chale, iske liye ek baar battery setting maangte hain. */
    private void maybeAskBattery() {
        SharedPreferences sp = getSharedPreferences(ReminderScheduler.PREFS, MODE_PRIVATE);
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (sp.getBoolean("battery_asked", false)
                || (pm != null && pm.isIgnoringBatteryOptimizations(getPackageName()))) return;
        sp.edit().putBoolean("battery_asked", true).apply();
        new AlertDialog.Builder(this)
                .setTitle("Reminder ke liye ek setting")
                .setMessage("App band hone par bhi notification aaye, isliye is app ko battery optimization se bahar rakho. "
                        + "Next screen par \"Allow\" dabao.\n\n"
                        + "Oppo / ColorOS: Settings \u2192 Battery \u2192 Milkman PRO \u2192 \"Allow background activity\" "
                        + "aur App info \u2192 \"Auto launch\" ON karo.")
                .setPositiveButton("Settings kholo", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        try {
                            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                        } catch (Exception ignored) {
                        }
                    }
                })
                .setNegativeButton("Baad mein", null)
                .show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (web != null) web.saveState(outState);
    }

    @Override
    protected void onDestroy() {
        try {
            unregisterReceiver(smsSentReceiver);
        } catch (Exception ignored) {
        }
        if (web != null) {
            web.removeJavascriptInterface("Android");
            web.destroy();
        }
        super.onDestroy();
    }
}
