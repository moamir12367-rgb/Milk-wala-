package com.milkman.pro;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

/** HTML ke window.Android.* functions yahin se chalte hain. */
public class AndroidBridge {
    private final MainActivity act;

    AndroidBridge(MainActivity a) {
        this.act = a;
    }

    private static String safeName(String n, String fallback) {
        if (n == null || n.trim().isEmpty()) return fallback;
        return n.replaceAll("[^A-Za-z0-9._ -]", "_");
    }

    private void toast(final String msg) {
        act.runOnUiThread(() -> Toast.makeText(act, msg, Toast.LENGTH_LONG).show());
    }

    @JavascriptInterface
    public boolean hasSmsPermission() {
        return ContextCompat.checkSelfPermission(act, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    @JavascriptInterface
    public void requestSmsPermission() {
        act.runOnUiThread(() -> act.requestSmsPermission());
    }

    @JavascriptInterface
    public void sendSms(final String number, final String text, final String reqId) {
        act.runOnUiThread(() -> act.sendSmsNow(number, text, reqId));
    }

    @JavascriptInterface
    public void scheduleReminders(String json) {
        ReminderScheduler.saveReminders(act, json == null ? "[]" : json);
        ReminderScheduler.scheduleAll(act);
    }

    @JavascriptInterface
    public void showNotification(String title, String body) {
        final String t = title == null ? ReminderScheduler.TITLE : title;
        final String b = body == null ? "" : body;
        AlarmService.start(act, "test", t, b);
        act.runOnUiThread(() -> act.startActivity(new Intent(act, AlarmActivity.class)
                .putExtra("id", "test").putExtra("title", t).putExtra("body", b)));
    }

    @JavascriptInterface
    public void saveFile(String base64, String filename, String mime) {
        String name = safeName(filename, "milkman_file");
        String type = (mime == null || mime.isEmpty()) ? "application/octet-stream" : mime;
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, type);
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                v.put(MediaStore.Downloads.IS_PENDING, 1);
                ContentResolver cr = act.getContentResolver();
                Uri uri = cr.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) throw new Exception("Downloads mein file nahi ban saki");
                try (OutputStream os = cr.openOutputStream(uri)) {
                    if (os == null) throw new Exception("File open nahi hui");
                    os.write(data);
                }
                v.clear();
                v.put(MediaStore.Downloads.IS_PENDING, 0);
                cr.update(uri, v, null, null);
                toast("Downloads mein save ho gayi: " + name);
            } else {
                File dir = act.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS);
                if (dir == null) dir = act.getFilesDir();
                dir.mkdirs();
                File f = new File(dir, name);
                try (FileOutputStream fo = new FileOutputStream(f)) {
                    fo.write(data);
                }
                toast("Save ho gayi: " + f.getAbsolutePath());
            }
        } catch (Exception e) {
            toast("Save nahi hui: " + e.getMessage());
        }
    }

    @JavascriptInterface
    public void shareImage(String base64, String filename, String caption) {
        try {
            byte[] data = Base64.decode(base64, Base64.DEFAULT);
            File dir = new File(act.getCacheDir(), "shared");
            dir.mkdirs();
            File f = new File(dir, safeName(filename, "bill.jpg"));
            try (FileOutputStream fo = new FileOutputStream(f)) {
                fo.write(data);
            }
            final Uri uri = FileProvider.getUriForFile(act, act.getPackageName() + ".fileprovider", f);
            final Intent send = new Intent(Intent.ACTION_SEND);
            send.setType("image/jpeg");
            send.putExtra(Intent.EXTRA_STREAM, uri);
            if (caption != null && !caption.isEmpty()) send.putExtra(Intent.EXTRA_TEXT, caption);
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            act.runOnUiThread(() -> act.startActivity(Intent.createChooser(send, "Bill share karo")));
        } catch (Exception e) {
            toast("Share nahi hua: " + e.getMessage());
        }
    }
}
