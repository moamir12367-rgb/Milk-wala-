package com.milkman.pro;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Phone restart / time change / app update ke baad alarms dobara lagata hai. */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        ReminderScheduler.scheduleAll(context);
    }
}
